function confirmFormValidation() {
  event.preventDefault();
  console.log("called");
  document.getElementById("confirmForm").disabled = true;

  if (document.getElementsByClassName("alert-danger").length == 1) {
    document.getElementsByClassName("alert-danger")[0].style.display = "none";
  } else if (document.getElementsByClassName("alert-danger").length == 2) {
    document.getElementsByClassName("alert-danger")[0].style.display = "none";
    document.getElementsByClassName("alert-danger")[1].style.display = "none";
  }

  var validationFail = commonConsumerlFieldValidations();

 

  

  if (validationFail == true) {
    document.getElementById("confirmForm").disabled = false;

    document.getElementById("settimeout").style.display = "block";
    document.getElementById("settimeout").scrollIntoView();
    return false;
  } else {
    document.getElementById("settimeout").style.display = "none";
    var modal = document.getElementById('exampleModalCenter');
        modal.style.display = 'block';
//       // Displaying the modal
//       var modal = document.getElementById("exampleModalToggle");
//       modal.style.display = "block";

//       // Optionally, you can also add a class to make it visible if using CSS
//       // modal.classList.add("show");
//  ;
    return true;
  }
}

document.getElementById('closePopUp').addEventListener('click',()=>{
  var modal = document.getElementById('exampleModalCenter');
    modal.style.display = 'none';
})

function commonConsumerlFieldValidations() {
  // Clear previous errors
  const errorIds = [
    'errorHolderName', 'errorIfsc', 'errorAccountNo', 'errorConfirmAcc',
    'errorAddress', 'errorBankType', 'errorBankname', 'errorIdType',
    'errorIdNumber', 'errorCheckbox'
  ];
  errorIds.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = "";
  });

  const upiError = document.getElementById("upiError");
  const upiSuccess = document.getElementById("upiSuccess");
  const upiIdInput = document.getElementById("upiIdInput");
  if (upiError) upiError.style.display = "none";
  if (upiSuccess) upiSuccess.style.display = "none";
  if (upiIdInput) upiIdInput.style.border = "1px solid #ced4da";

  var validationFail = false;

  if (isAccInfoRequired) {
    var id_type = document.getElementById('id_type');
    var id_number = document.getElementById('id_number');
    var holder_name = document.getElementById("holder_name");
    var ifsc = document.getElementById("ifsc");
    var bank_name = document.getElementById('bankname');
    var bank_type = document.getElementById('account_type');
    var account_number = document.getElementById('account_number');
    var confirm_account_number = document.getElementById('confirm_account_number');
    var checkboxVal = document.getElementById('checkAgree');

    var accountNumberRegex = /^(?=.*[a-zA-Z0-9])[a-zA-Z0-9.-/]{5,20}$/;
    var ifscRegex = /^[A-Za-z]{4}[0][a-zA-Z0-9]{6}$/;

    // id type validation
    if (id_type.value === '') {
      showError('errorIdType', "- Id type required", id_type);
      validationFail = true;
    } else {
      hideError('errorIdType', id_type);
    }

    // id number validation
    if (id_number.value === '') {
      showError('errorIdNumber', "- Id number is Mandatory", id_number);
      validationFail = true;
    } else if (isValidIdNumber(id_type.value, id_number.value)) {
      hideError('errorIdNumber', id_number);
    } else {
      showError('errorIdNumber', "- Invalid Id Number", id_number);
      validationFail = true;
    }

    // Account holder Name
    if (holder_name.value.trim().length <= 3 || holder_name.value.trim().length >= 80) {
      showError('errorHolderName', "- Account Holder Name should be between 3 to 80 character.", holder_name);
      validationFail = true;
    } else {
      hideError('errorHolderName', holder_name);
    }

    // IFSC code validator
    if (ifsc.value.trim().length < 11) {
      showError('errorIfsc', "- IFSC code should be 11 digital number", ifsc);
      validationFail = true;
    } else if (ifscRegex.test(ifsc.value) == false) {
      showError('errorIfsc', "- Invalid IFSC Code", ifsc);
      validationFail = true;
    } else {
      hideError('errorIfsc', ifsc);
    }

    // Bank Name
    if (bank_name.value.trim().length <= 3 || bank_name.value.trim().length >= 50) {
      showError('errorBankname', "- Bank Name should be between 3 to 50 character.", bank_name);
      validationFail = true;
    } else {
      hideError('errorBankname', bank_name);
    }

    // Bank account type
    if (bank_type.value === '') {
      showError('errorBankType', "- Select Bank Type", bank_type);
      validationFail = true;
    } else {
      hideError('errorBankType', bank_type);
    }

    // account number
    if (account_number.value.trim().length <= 5 || account_number.value.trim().length >= 20) {
      showError('errorAccountNo', "- Account Number should have miniumum 6 characters.", account_number);
      validationFail = true;
    } else if (accountNumberRegex.test(account_number.value) === false) {
      showError('errorAccountNo', "- Invalid Account Number", account_number);
      validationFail = true;
    } else {
      hideError('errorAccountNo', account_number);
    }

    // confirm Account number
    if (confirm_account_number.value.trim().length <= 5 || confirm_account_number.value.trim().length >= 20) {
      showError('errorConfirmAcc', "- Account Number should between 6 to 20 Digit", confirm_account_number);
      validationFail = true;
    } else if (accountNumberRegex.test(confirm_account_number.value) === false || account_number.value !== confirm_account_number.value) {
      showError('errorConfirmAcc', "- Invalid Confirm Account Number", confirm_account_number);
      validationFail = true;
    } else {
      hideError('errorConfirmAcc', confirm_account_number);
    }

    if (checkboxVal && !checkboxVal.checked) {
      showError('errorCheckbox', "- Please Agree by checking the box");
      validationFail = true;
    } else {
      hideError('errorCheckbox');
    }

  } else {
    // UPI Validation
    const upiRegex = /^[a-zA-Z0-9.\-_]{2,256}@(?!.*@)[a-zA-Z0-9]{2,64}$/;
    const checkboxValUpi = document.getElementById('checkAgreeUpi');

    if (!upiIdInput || upiIdInput.value.trim() === "") {
      if (upiError) {
        upiError.style.display = "flex";
        document.getElementById("upiErrorMsg").innerText = "Please enter your UPI ID";
      }
      if (upiIdInput) upiIdInput.style.border = "1px solid red";
      validationFail = true;
    } else if (!upiRegex.test(upiIdInput.value.trim())) {
      if (upiError) {
        upiError.style.display = "flex";
        document.getElementById("upiErrorMsg").innerText = "Please enter a valid UPI ID";
      }
      upiIdInput.style.border = "1px solid red";
      validationFail = true;
    }

    if (checkboxValUpi && !checkboxValUpi.checked) {
      showError('errorCheckbox', "- Please Agree by checking the box"); // Reuse error checkbox area if suitable or handle separately
      validationFail = true;
    }
  }

  return validationFail;
}

function showError(id, msg, el) {
  const errEl = document.getElementById(id);
  if (errEl) {
    errEl.style.visibility = "visible";
    errEl.innerHTML = msg;
    errEl.style.display = "block";
  }
  if (el) el.style.border = "thin solid red";
}

function hideError(id, el) {
  const errEl = document.getElementById(id);
  if (errEl) {
    errEl.style.visibility = "hidden";
    errEl.style.display = "none";
  }
  if (el) {
    el.style.removeProperty("border-color");
    el.style.removeProperty("border-width");
  }
}

function isValidIdNumber(type,idNumber) {
  var panCardRegex = /^((([a-zA-Z][ ,-\/]*){3})(([H|P|h|p][ ,-\/]*){1})(([a-zA-Z][ ,-\/]*){1})(([0-9][ ,-\/]*){4})(([a-zA-Z][ ,-\/]*){1})(([A-Za-z0-9][ ,-\/]*){0,20}))$/;
  var passportRegex = /^((([a-zA-Z][ ,\/,:-]*){1})([0-9][ ,\/,:-]*){6,9})$/;
  var voterIdRegex = /^((([a-zA-Z][ ,\/,-]*){2})(([0-9][ ,\/,-]*){7,28})|(([a-zA-Z][ ,\/,-]*){3})(([0-9][ ,\/,-]*){6,27}))$/;			
  var drivingLincenceRegex = /^[a-zA-Z0-9 -]{1,30}$/;
  var rationCardRegex = /^[a-zA-Z0-9 -]{1,30}$/;
  let isValid = true;
  switch (type) {
    case 'pan':
      isValid = panCardRegex.test(idNumber);
      break;
    case 'passport':
      isValid = passportRegex.test(idNumber);
      break;
    case 'voterId':
      isValid = voterIdRegex.test(idNumber);
      break;
    case 'driversLicense':
      isValid = drivingLincenceRegex.test(idNumber);
      break;
    case 'ration':
      isValid = rationCardRegex.test(idNumber);
      break;
    default:
      break;
  }
  return isValid;
}

